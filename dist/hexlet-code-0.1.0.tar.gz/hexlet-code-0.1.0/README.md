### Hexlet tests and linter status:
[![Actions Status](https://github.com/Madixxx22/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Madixxx22/python-project-50/actions)

[![Check Python CI](https://github.com/Madixxx22/python-project-50/actions/workflows/checksci.yml/badge.svg)](https://github.com/Madixxx22/python-project-50/actions/workflows/checksci.yml)

[![Maintainability](https://api.codeclimate.com/v1/badges/fdd5434031d87acc758e/maintainability)](https://codeclimate.com/github/Madixxx22/python-project-50/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/fdd5434031d87acc758e/test_coverage)](https://codeclimate.com/github/Madixxx22/python-project-50/test_coverage)
