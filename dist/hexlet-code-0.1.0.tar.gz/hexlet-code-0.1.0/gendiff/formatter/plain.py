def to_plain(data):
    pass
