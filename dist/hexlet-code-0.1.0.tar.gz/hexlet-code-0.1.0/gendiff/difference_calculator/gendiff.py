import json


def generate_diff(first_file:str, second_file:str) -> str:
    result = []
    res_dict = {}
    file1 = json.load(open(first_file))
    file2 = json.load(open(second_file))

    for k, v in file1.items():
        if k in file2 and file1[k] == file2[k]:
            result.append({f'  {k}': v})
            res_dict.update(k,v)
        else:
            result.append({f'- {k}': v})
            res_dict.update(k,v)


    for k, v in file2.items():
        if k in file1 and file1[k] != file2[k]:
            result.append({f'+ {k}': v})
            res_dict.update(k,v)

        elif k not in file1:
            result.append({f'+ {k}': v})
            res_dict.update(k,v)

    #result.sort(key = lambda x: x[2])
    k = sorted(res_dict)
    print(k)
    return json.dumps(result, indent=4)