# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['difference_calculator', 'difference_calculator.scripts']

package_data = \
{'': ['*']}

install_requires = \
['argparse>=1.4.0,<2.0.0']

entry_points = \
{'console_scripts': ['gendiff = difference_calculator.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Hexlet project difference calculator',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Madixxx22/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Madixxx22/python-project-50/actions)',
    'author': 'Madixxx22',
    'author_email': 'vysokolyan2016@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/Madixxx22/python-project-50',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
