# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff',
 'gendiff.difference_calculator',
 'gendiff.formatter',
 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['PyYAML>=6.0,<7.0',
 'argparse>=1.4.0,<2.0.0',
 'flake8>=5.0.4,<6.0.0',
 'pytest-cov>=4.0.0,<5.0.0',
 'pytest>=7.2.0,<8.0.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'Hexlet project difference calculator',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/Madixxx22/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/Madixxx22/python-project-50/actions)\n\n[![Check Python CI](https://github.com/Madixxx22/python-project-50/actions/workflows/checksci.yml/badge.svg)](https://github.com/Madixxx22/python-project-50/actions/workflows/checksci.yml)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/fdd5434031d87acc758e/maintainability)](https://codeclimate.com/github/Madixxx22/python-project-50/maintainability)\n\n[![Test Coverage](https://api.codeclimate.com/v1/badges/fdd5434031d87acc758e/test_coverage)](https://codeclimate.com/github/Madixxx22/python-project-50/test_coverage)\n',
    'author': 'Madixxx22',
    'author_email': 'vysokolyan2016@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/Madixxx22/python-project-50',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
