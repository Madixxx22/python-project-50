import argparse
from gendiff.difference_calculator.gendiff import generate_diff


def main():
    '''
    The script is responsible for checking two flat json files
    Takes two lines of file paths as input and returns a line with the comparison
    '''
    desc = "Compares two configuration files and shows a difference."
    parser = argparse.ArgumentParser(description=desc)
    parser.add_argument("first_file", type=str, default="")
    parser.add_argument("second_file", type=str, default="")
    parser.add_argument("-f", "--format", type=str, default="json",
                        help="set format of output")
    args = parser.parse_args()
    result = generate_diff(first_file=args.first_file,
                        second_file=args.second_file)
    print(result)
    return result



if __name__ == '__main__':
    main()
